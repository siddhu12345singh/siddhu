#include<stdio.h>
int rev(char *a[],int n,char *b[],int m)
{
    
}